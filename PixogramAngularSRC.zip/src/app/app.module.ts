import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule,routingcomponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { MyMediaPageComponent } from './my-media-page/my-media-page.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { NewsFeedComponent } from './news-feed/news-feed.component';
import { SearchComponent } from './search/search.component';
import { BlockedAccountsComponent } from './blocked-accounts/blocked-accounts.component';
import { UploadMediaMultipleComponent } from './upload-media-multiple/upload-media-multiple.component';
import { UploadSingleMediaComponent } from './upload-single-media/upload-single-media.component';
import { FollowersComponent } from './followers/followers.component';

@NgModule({
  declarations: [
    AppComponent,
    routingcomponents,
    RegisterComponent,
    MyMediaPageComponent,
    AccountDetailsComponent,
    NewsFeedComponent,
    SearchComponent,
    BlockedAccountsComponent,
    UploadMediaMultipleComponent,
    UploadSingleMediaComponent,
    FollowersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
