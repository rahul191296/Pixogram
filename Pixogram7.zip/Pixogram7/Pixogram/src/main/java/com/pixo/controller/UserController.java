package com.pixo.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.User;
import com.pixo.dao.UserDAO;
import com.pixo.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDAO userDAO;
	
	
	
	
	@GetMapping("/registerUser")
	ResponseEntity<Void>  registerUser(@ModelAttribute User user){
		ResponseEntity<Void> response=null;
		boolean result=userService.registerUser(user);
		if(result)
		{	
		response=new ResponseEntity<Void>(HttpStatus.OK);
		}	
		else
		{
			
		response=new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	}
		return response;
	}
	
	
	
	@PostMapping("/LoginUser")
	ResponseEntity<Void>  UserAuthentication(@RequestParam("EmailId") String emailId,@RequestParam("Password") String password,HttpServletRequest request){	
		
		ResponseEntity<Void> response=null;
		      	      
	  	
    	boolean result=userService.authenticate(emailId, password);
    	HttpSession session=request.getSession();
    	session.setAttribute("EmailId", emailId);
    	
    	if(result){
    	
    		User user=userService.getUser(emailId);
    		String name=user.getName();
    		int id=user.getId();
    		session.setAttribute("UserId", id);
    		response=new ResponseEntity<Void>(HttpStatus.OK);
    		
    	}
    	else{	
    		
    		response=new ResponseEntity<Void>(HttpStatus.CONFLICT);
    	}   	
    	return response;
    }
	
	 @PostMapping("/uploadPicture")
	 ResponseEntity<Void> handleFileUpload(HttpServletRequest request,@RequestParam CommonsMultipartFile[] profilePicture) throws Exception {
		 ResponseEntity<Void> response=null;
	        if (profilePicture != null && profilePicture.length > 0) {
	            for (CommonsMultipartFile aFile : profilePicture)
	            {      
	               // System.out.println("Saving file: " + aFile.getOriginalFilename());
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                ProfilePicture pic = new ProfilePicture();
	                pic.setFileName(aFile.getOriginalFilename());
	                pic.setData(aFile.getBytes());
	                pic.setUserId(userId);
	                boolean result=userDAO.uploadProfilePicture(pic);
	                if(result)
	                {
	                	response=new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	                }
	            }
	        }	  
	        return response;
	    }
	 @PostMapping("/showImage")
	 ResponseEntity<Void> showImage(HttpServletRequest request, HttpServletResponse response){	
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	int userId=(int)request.getSession().getAttribute("UserId"); 
	    	ProfilePicture picture=userDAO.showImage(userId);
	    	
	    	response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
	        try {
				response.getOutputStream().write(picture.getData());
				response.getOutputStream().close();
				responseEntity=new ResponseEntity<Void>(HttpStatus.ACCEPTED);
			} catch (IOException e) {			
				e.printStackTrace();
			}	        	   
	    	return responseEntity;
	    }
	 
	 @PostMapping("/uploadMedia")
	 ResponseEntity<Void> uploadMedia(HttpServletRequest request,@RequestParam CommonsMultipartFile[] media,@RequestParam("title") String title,
	    		@RequestParam("description") String description,@RequestParam("tags") String tags) throws Exception {
		 ResponseEntity<Void> responseEntity=null;
	        if (media != null && media.length > 0) {
	            for (CommonsMultipartFile aFile : media)
	            {      
	                //System.out.println("Saving file: " + aFile.getOriginalFilename());
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                MyMedia myMedia=new MyMedia();
	                myMedia.setMedia(aFile.getBytes());
	                myMedia.setTitle(title);
	                myMedia.setDescription(description);
	                myMedia.setTag(tags);
	                myMedia.setUserId(userId);
	                boolean result=userDAO.uploadMedia(myMedia);
	                if(result)
	                {
	                	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
	                }
	                else
	                {
	                	responseEntity=new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	                }
	            }
	        }	  
	        return responseEntity;
	    }
	 	@PostMapping("/uploadMultipleMedia")
	 	ResponseEntity<Void> uploadMultipleMedia(HttpServletRequest request,@RequestParam CommonsMultipartFile[] media,@RequestParam("title") String title,
	    		@RequestParam("description") String description,@RequestParam("tags") String tags) throws Exception {
	 		 ResponseEntity<Void> responseEntity=null;
	        if (media != null && media.length > 0) {
	            for (CommonsMultipartFile aFile : media)
	            {      
	                System.out.println("Saving file: " + aFile.getOriginalFilename());
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                MyMedia myMedia=new MyMedia();
	                myMedia.setMedia(aFile.getBytes());
	                myMedia.setTitle(title);
	                myMedia.setDescription(description);
	                myMedia.setTag(tags);
	                myMedia.setUserId(userId);
	                boolean result=userDAO.uploadMedia(myMedia);
	                if(result)
	                {
	                	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
	                }
	                else
	                {
	                	responseEntity=new ResponseEntity<Void>(HttpStatus.CONFLICT);
	                }
	            }
	        }	  
	        return responseEntity;
	    }
	 	@GetMapping("/welcome")
		ResponseEntity<Void> WelcomePage(HttpServletRequest request){	
			
			      	      
			 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
	    	return responseEntity;
	    }
	 
	 @PostMapping("/accountUpdate")
	 ResponseEntity<Void> accountUpdatePage(HttpServletRequest request){
		 
		  	      
			 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	//System.out.println("email id is "+emailId);
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			return responseEntity;
		}
	 
	 @PostMapping("/news")
	 ResponseEntity<Void> News(HttpServletRequest request){
		      	      
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	System.out.println("email id is "+emailId);
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			
			return responseEntity;
		}
	 @GetMapping("/singlemedia")
	 ResponseEntity<Void> UploadSinglePage(HttpServletRequest request){
		      	      
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	System.out.println("email id is "+emailId);
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			return responseEntity;
		}
	 @GetMapping("/multiplemedia")
	 ResponseEntity<Void> UploadMultiplePage(HttpServletRequest request){
		      	      
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	System.out.println("email id is "+emailId);
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			return responseEntity;
		}
	 @GetMapping("/home")
	 ResponseEntity<Void> Home(HttpServletRequest request){
		  	      
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	System.out.println("email id is "+emailId);
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			
			return responseEntity;
		}
	 
}
