package com.pixo.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;


import org.springframework.stereotype.Repository;

import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.User;

@Repository
public class UserDAOImpl implements UserDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	public UserDAOImpl() {
    }

	
	@Transactional
	public boolean registerUser(User user) {
		
		manager.persist(user);
		
		return true;
		
	}

	@Transactional
	public boolean authenticate(String email, String password) {
		Query query=manager.createQuery("from User where EmailId=? and Password=?");
		query.setParameter(0,email);
		query.setParameter(1,password);
		User user=(User)query.getSingleResult();
		return true;
	}

	@Transactional
	public User getUser(String email) {
		
		Query query=manager.createQuery("from User where EmailId=?");
		query.setParameter(0,email);
		User user=(User)query.getSingleResult();
		return user;
	}

	@Transactional
	public boolean uploadProfilePicture(ProfilePicture pic) {
		manager.persist(pic);
		return true;	
	}

	@Transactional
	public ProfilePicture showImage(int id) {
		
		Query query=manager.createQuery("from ProfilePicture where userId=?");
		query.setParameter(0,id);
		ProfilePicture file=(ProfilePicture)query.getSingleResult();
		return file;	
	}

	@Transactional
	public boolean uploadMedia(MyMedia myMedia) {
	manager.persist(myMedia);
		return true;
	}

}
