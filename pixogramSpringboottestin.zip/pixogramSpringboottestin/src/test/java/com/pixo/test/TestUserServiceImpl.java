package com.pixo.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


import com.pixo.bean.User;
import com.pixo.dao.UserDAO;
import com.pixo.service.UserServiceImpl;


public class TestUserServiceImpl {
	private MockMvc mockMvc;
	@InjectMocks
	private UserServiceImpl userServiceImpl;
	
	@Autowired
	@Spy
	private UserDAO userDAO;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(userServiceImpl).build();
	}

	
	@Test
	public void testRegisterUser() {
		User user=new User();
		user.setEmail("rahul@gmail.com");
		user.setName("Rahul");
		user.setPassword("Rahul62@");
	//user.setId(12);
		user.setConpassword("Rahul62@");
	boolean res = userServiceImpl.registerUser(user);
	assertEquals(false,res);
	}
	
	@Test 
	public void testAuthenticate() {

		boolean status = userServiceImpl.authenticate("ghu@fhg.hki","Rahul@");
		assertEquals(false, status);
	}

}
		

