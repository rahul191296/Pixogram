package com.pixo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.User;

@Repository
public class UserDAOImpl implements UserDAO {

	
	
	@Autowired
	@PersistenceContext
	private EntityManager manager;
	public UserDAOImpl() {
    }


	
	@Transactional
	public boolean registerUser(User user) {
		
		manager.persist(user);
		return true;
		
	}

	@Transactional
	public boolean authenticate(String email, String Password) {
		
		Query query=manager.createQuery("from User o where o.email =:email  and o.Password =:Password");
		
		query.setParameter("email",email);
		query.setParameter("Password",Password);
		List<User> List=query.getResultList();
		
		if(List.isEmpty())
			return false;
		else
			return true;
		}

	@Transactional
	public User getUser(String email) {
		
		
		Query query=manager.createQuery("from User where email=email");
		query.setParameter("email",email);
		User user=(User)query.getSingleResult();
		return user;
	}

	@Transactional
	public boolean uploadProfilePicture(ProfilePicture pic) {
		manager.persist(pic);
		return true;	
	}

	@Transactional
	public ProfilePicture showImage(int id) {
		
		Query query=manager.createQuery("from ProfilePicture where userId=?");
		query.setParameter(0,id);
		ProfilePicture file=(ProfilePicture)query.getSingleResult();
		return file;	
	}

	@Transactional
	public boolean uploadMedia(MyMedia myMedia) {
		manager.persist(myMedia);
		
		return true;
	}

}
